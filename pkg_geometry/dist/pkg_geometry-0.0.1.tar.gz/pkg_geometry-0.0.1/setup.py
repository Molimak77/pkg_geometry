# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['pkg_geometry']

package_data = \
{'': ['*']}

setup_kwargs = {
    'name': 'pkg-geometry',
    'version': '0.0.1',
    'description': 'the package geometry permit to computed the metric of the geometries',
    'long_description': '# pkg_geometry\nthe python package destined to trait the geometry computers \n\n#### Purpose of the pacakge \n+ The purpose of the package is to computed the essential metrics \n\n### Features\n+ class facequadi\n\t- perimetre\n\t- surface\n\t- volume\n\n\n### Getting Started \nThe package can be found  on pypi\n\n### installation \n```terminal\npip install pkg_geometry\n```\n\n\n### Usage\nCompute the perimetre \n\n```{python}\n>>> from pkg_geometry.geometry import facequadri as fc\n>>> fac_fig = fc(2,3,4)\n>>> fac_fig.perimetre()\n```\n\ncompute the surce \n\n```python\n>>> from pkg_geometry.geometry import facequadri as fc\n>>> fac_fig = fc(2,3,4)\n>>> fac_fig.surface()\n```\n\nCompute the volume \n\n```python\n>>> from pkg_geometry.geometry import facequadri as fc\n>>> fac_fig = fc(2,3,4)\n>>> fac_fig.perimetre\n```\n\n\n\n### Contribution\nContribution are welcom. Notice a lbug let us know. Thans\n\n\n### Author \n+ MAin MAintainer: Molière Nguile-Makao\n+ [molier.nguile@gmail.com](#molier.nguile@gmail.com)\n',
    'author': 'molierenguile-makao',
    'author_email': 'moliere.nguile@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': 'https://github.com/Molimak77/pkg_geometry',
    'packages': packages,
    'package_data': package_data,
    'python_requires': '>=3.7,<4.0',
}


setup(**setup_kwargs)
